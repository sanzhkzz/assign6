package endterm.project.factoryMethod;

public interface Transport {
    void deliver();
}
