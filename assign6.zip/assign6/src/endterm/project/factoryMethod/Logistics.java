package endterm.project.factoryMethod;

public interface Logistics {
    Transport createTransport() ;
}
